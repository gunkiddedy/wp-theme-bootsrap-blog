<div class="custom-header">
    <div class="jumbotron p-4 p-md-5 rounded bg-dark" style="background-image:url(<?php echo get_theme_file_uri( "img/nature1.jpg" )?>)">
        <div class="col-md-6 px-0">
          <h1 class="display-4 font-italic">The awesome place of Gunungkidul</h1>
          <p class="lead my-3">Gunungkidul merupakan kabupaten yang mempunyai pesona alam yang begitu mempesona</p>
          <p class="lead mb-0"><a href="#" class=" font-weight-bold">Continue reading...</a></p>
        </div>
    </div>
</div>

<div class="set-header">
    <h3><?php bloginfo( 'name' ) ?></h3>
</div>